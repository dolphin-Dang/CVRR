All codes are in `solutions/`. The code can be executed as follow steps:

1. cd solutions/
2. change mode config ("auto" or "manual") in `solutions/selectPoints.m`
3. change numPoints config in `solutions/selectPoints.m`
4. change img1 & img2 paths in the 3 files
5. execute `solutions/selectPoints.m`
6. execute `solutions/computeH.m`
7. execute `solutions/warp.m`


